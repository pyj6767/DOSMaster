# Copyright (c) CNMD Youngjun Park, Jaeson Kim

"""
dosmaster is a code that conveniently manipulates DOS(Density Of States).
"""

__version__ = "1.4.2"
